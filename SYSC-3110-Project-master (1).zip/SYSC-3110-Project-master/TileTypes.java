/**
 * Enum for tile type
 * @author Hoang Bui 101029049
 *
 */

public enum TileTypes {
	GRASS, ZOMBIE_SPAWN;
}
