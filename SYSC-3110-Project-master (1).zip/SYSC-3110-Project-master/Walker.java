/**
 * Class for walker zombie
 * 
 * @author Hoang Bui 1010129049
 * @version 2, October 16 2018
 */
public class Walker extends Zombie{
	public Walker() {
		super(3, 10, 30, 1, ZombieTypes.WALKER);
	}
}
