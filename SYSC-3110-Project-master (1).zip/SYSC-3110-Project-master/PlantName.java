/**
 * 
 * @author Souheil Yazji 101007994
 *
 */
public enum PlantName {
	PeaShooter, SunFlower
}
