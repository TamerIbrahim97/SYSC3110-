/**
 * Enum file to hold all zombie types
 * @author Hoang Bui 101029049
 * @version 1
 */

public enum ZombieTypes {
	WALKER;
}
