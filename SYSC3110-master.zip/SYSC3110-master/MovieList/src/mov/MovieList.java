package mov;

import java.util.ArrayList;

public class MovieList extends ArrayList<Movie>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	
}
