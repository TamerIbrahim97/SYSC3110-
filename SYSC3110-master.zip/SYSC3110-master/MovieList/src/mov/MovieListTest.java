package mov;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MovieListTest {
	MovieList emptyList;;
	@Before
	public void setUp() throws Exception {
	emptyList = new MovieList();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
		assertEquals(1,1,0.001);
	}

}
