package bag;

public class MessagePipe {
	
	public void send(Bag bag){
		System.out.println(bag);
	}

}
