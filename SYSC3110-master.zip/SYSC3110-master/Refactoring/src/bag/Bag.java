package bag;

public interface Bag {

	public void set(Object o);
	
	public Object get();
	
}
