package sig;

public class MethodCallExample {

	public void callTest()
	 {
		 float r;
	     MethodSigExample eg = new MethodSigExample();
	     r = eg.test("hello", 10, "world");
	 }
	
}
