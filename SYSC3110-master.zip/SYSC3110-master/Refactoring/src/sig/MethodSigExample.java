package sig;

public class MethodSigExample
{
   public float test(String s, int i, String s2)
   {
      int x = i + s.length();
      return x;
   }
}