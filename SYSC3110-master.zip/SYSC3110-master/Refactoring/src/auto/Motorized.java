package auto;

public interface Motorized {

	public abstract String getMotor();

	public abstract void setMotor(String string);

}