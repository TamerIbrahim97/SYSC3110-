package auto;

public abstract class Vehicle
{
   protected int passengers;
   public int getPassengers()
   {
      return passengers;
   }
   public void setPassengers(int i)
   {
      passengers = i;
   }
}