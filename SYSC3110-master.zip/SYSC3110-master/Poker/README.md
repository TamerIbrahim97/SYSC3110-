Poker
=====

A simple poker hand ranking program
