BuddyInfo
=========

This is a sample contacts application for SYSC 3110 - Project Development
